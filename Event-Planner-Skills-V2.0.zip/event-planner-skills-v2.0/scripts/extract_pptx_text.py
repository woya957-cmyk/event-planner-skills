#!/usr/bin/env python3
"""Extract slide and speaker-note text in presentation order; no OCR/visual inference."""
import argparse,json,posixpath,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def extract(path):
    result=[]
    with zipfile.ZipFile(path) as z:
        if sum(x.file_size for x in z.infolist())>300_000_000:raise ValueError('PPTX expanded data exceeds 300MB; inspect separately')
        pres=ET.fromstring(z.read('ppt/presentation.xml'))
        rels=ET.fromstring(z.read('ppt/_rels/presentation.xml.rels'))
        targets={x.attrib['Id']:x.attrib['Target'] for x in rels}
        for page,s in enumerate(pres.findall('p:sldIdLst/p:sldId',NS),1):
            target=targets[s.attrib['{'+NS['r']+'}id']]
            sp=target.lstrip('/') if target.startswith('/') else posixpath.normpath('ppt/'+target)
            root=ET.fromstring(z.read(sp)); texts=[x.text for x in root.findall('.//a:t',NS) if x.text]
            notes=[];rp=posixpath.dirname(sp)+'/_rels/'+posixpath.basename(sp)+'.rels'
            if rp in z.namelist():
                for rel in ET.fromstring(z.read(rp)):
                    if rel.attrib.get('Type','').endswith('/notesSlide') and rel.attrib.get('TargetMode')!='External':
                        nt=rel.attrib['Target'];np=nt.lstrip('/') if nt.startswith('/') else posixpath.normpath(posixpath.dirname(sp)+'/'+nt)
                        nr=ET.fromstring(z.read(np));notes=[x.text for x in nr.findall('.//a:t',NS) if x.text]
            result.append({'page':page,'slide_part':sp,'text':texts,'notes':notes,'visual_analysis':'not_performed'})
    return {'file_id':path.stem,'file':path.name,'slides':result,'warning':'文本证据种子；需渲染图片与用户评价后才能提炼审美。'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('pptx');ap.add_argument('output');a=ap.parse_args()
    target=Path(a.output)
    if target.exists():raise SystemExit('output exists; choose a new evidence filename')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(extract(Path(a.pptx)),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
if __name__=='__main__':main()
