#!/usr/bin/env python3
"""Schema + cross-file business checks. Does not render or rate visual quality."""
import argparse, csv, json, sys
from decimal import Decimal
from pathlib import Path
from jsonschema import Draft202012Validator
from capacity import calculate
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads(p.read_text(encoding='utf8'))
def validate(folder):
    errors=[];warnings=[];data={}
    for f,s in [('project','event-project'),('concept','creative-concept'),('slides','slide'),('show-program','show-program'),('capacity','capacity')]:
        try:
            d=load(folder/(f+'.json'));schema=load(ROOT/'schemas'/(s+'.schema.json'))
            Draft202012Validator.check_schema(schema)
            issues=list(Draft202012Validator(schema).iter_errors(d))
            errors.extend(f'{f}:{list(e.absolute_path)}:{e.message}' for e in issues)
            data[f]=d
        except (OSError,ValueError) as e: errors.append(str(e))
    if errors:return {'errors':errors,'warnings':warnings}
    pid=data['project']['project_id']
    for key,d in data.items():
        if d['project_id'] != pid:errors.append(key+': project_id mismatch')
    slides=data['slides']['slides']; ids=[s['id'] for s in slides]
    if len(ids)!=len(set(ids)):errors.append('duplicate slide id')
    for slide in slides:
        for b in slide['blocks']:
            if b['kind']=='table' and any(len(row)!=len(b['headers']) for row in b['rows']):errors.append(slide['id']+': ragged table')
            if b['kind']=='image':
                p=(folder/b['path']).resolve()
                if not p.is_relative_to(folder.resolve()):errors.append(slide['id']+': image path escapes project')
                elif not p.is_file():errors.append(slide['id']+': missing image '+b['path'])
                if b['actual_pixels'][0]<3840 or b['actual_pixels'][1]<2160:warnings.append(slide['id']+': image below 4K target; assess actual crop')
    programs=data['show-program']['programs']; pids=[p['id'] for p in programs]
    qids=[q['id'] for p in programs for q in p['cues']]
    if len(pids)!=len(set(pids)):errors.append('duplicate program id')
    if len(qids)!=len(set(qids)):errors.append('duplicate cue id')
    total_sec=sum(p['duration_sec']+p['transition_sec'] for p in programs)
    if total_sec>data['show-program']['window_sec']:errors.append('show exceeds window')
    if data['show-program']['window_sec']!=data['project']['facts']['duration_min']*60:errors.append('project/show window mismatch')
    if total_sec<data['show-program']['window_sec']:warnings.append('show has unallocated service/buffer time; complete rundown before execution')
    mediums={e['medium'] for e in data['concept']['extensions']}
    if len(mediums)<3:errors.append('concept requires three different media')
    try:
        with (folder/'budget.csv').open(encoding='utf8',newline='') as handle:
            rows=list(csv.DictReader(handle))
        budget=Decimal(0)
        if not rows:errors.append('empty budget')
        for r in rows:
            quantity=Decimal(r['quantity']);price=Decimal(r['unit_price_cny']);subtotal=Decimal(r['subtotal_cny'])
            if min(quantity,price,subtotal)<0:errors.append('negative budget input')
            if quantity*price!=subtotal:errors.append(r['id']+': budget formula mismatch')
            budget+=subtotal
        if budget>Decimal(str(data['project']['facts']['budget_cap'])):errors.append('budget exceeds cap')
    except (OSError,KeyError,ValueError,ArithmeticError) as e:errors.append('budget: '+str(e))
    cap=calculate(data['capacity'])
    if cap['shortfall']:warnings.append(f"CAPACITY BLOCKER for full participation: shortfall {cap['shortfall']}; redesign or explicitly narrow participation target")
    if data['capacity']['target']!=data['project']['facts']['attendees']:warnings.append('capacity target differs from attendees; document participation split')
    warnings.append('visual render, live editability, real brand evidence and engineering validation not performed by this script')
    return {'project_id':pid,'errors':errors,'warnings':warnings,'capacity':cap,'status':'schema_pass' if not errors else 'failed'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('project');ap.add_argument('--strict-capacity',action='store_true');a=ap.parse_args()
    result=validate(Path(a.project));print(json.dumps(result,ensure_ascii=False,indent=2))
    sys.exit(1 if result['errors'] or (a.strict_capacity and result.get('capacity',{}).get('shortfall',0)>0) else 0)
if __name__=='__main__':main()
