#!/usr/bin/env node
// Minimal authored adapter: three explicit layouts, all semantic text/table elements editable.
const fs=require('fs'),path=require('path'),pptxgen=require('pptxgenjs');
async function main(){
 const [input,output]=process.argv.slice(2);
 if(!input||!output)throw Error('Usage: node scripts/build_pptx.cjs slides.json output.pptx');
 if(fs.existsSync(output))throw Error('Output exists; choose a new version filename');
 const d=JSON.parse(fs.readFileSync(input,'utf8'));
 if(d.aspect_ratio!=='16:9'||!Array.isArray(d.slides))throw Error('Run validate_project.py first; expected 16:9 slide data');
 const supported=new Set(['CRE01','STR07','BUD01']);
 for(const s of d.slides){
  if(!supported.has(s.layout_id))throw Error('Layout not implemented: '+s.layout_id);
  if(s.headline.length>34||s.message.length>90)throw Error(s.id+': split excessive title/message before export');
  if(s.blocks.some(b=>b.kind==='image'))throw Error('Image placement requires a layout-specific implementation');
  if(s.layout_id==='CRE01' && (s.blocks.length!==1||s.blocks[0].kind!=='text'))throw Error('CRE01 requires one text mechanism');
  if(s.layout_id==='STR07' && (s.blocks.length!==3||s.blocks.some(b=>b.kind!=='text')))throw Error('STR07 requires three text pillars');
  if(s.layout_id==='BUD01' && (s.blocks.length!==1||s.blocks[0].kind!=='table'||s.blocks[0].rows.length>8||s.blocks[0].headers.length!==4))throw Error('BUD01 requires a 4-column table with at most 8 body rows');
  for(const b of s.blocks)if(b.kind==='text'&&(b.title.length>16||b.body.length>100))throw Error(s.id+': text exceeds starter layout bounds');
 }
 const p=new pptxgen();p.layout='LAYOUT_WIDE';p.author='Event Planner Skills';p.subject='Editable skeleton; visual review required';p.title=d.project_id;
 const font=process.env.EVENT_PPT_FONT||'Microsoft YaHei';p.theme={headFontFace:font,bodyFontFace:font,lang:'zh-CN'};
 const txt=(s,t,o)=>s.addText(t,{fontFace:font,color:'172B35',margin:0,breakLine:false,...o});
 d.slides.forEach((x,i)=>{
  const s=p.addSlide();s.background={color:'F6F4EF'};
  s.addShape(p.ShapeType.rect,{x:0,y:0,w:.18,h:7.5,fill:{color:'146C65'},line:{color:'146C65'}});
  txt(s,x.headline,{x:.65,y:.55,w:12,h:.9,fontSize:30,bold:true});
  txt(s,x.message,{x:.65,y:1.6,w:12,h:.7,fontSize:19,color:'49616A'});
  if(x.layout_id==='CRE01'){
   txt(s,x.blocks[0].title,{x:.8,y:3.0,w:10,h:.4,fontSize:18,color:'146C65'});
   txt(s,x.blocks[0].body,{x:.8,y:3.7,w:11.5,h:1.65,fontSize:27,bold:true});
  }else if(x.layout_id==='STR07'){
   x.blocks.forEach((b,j)=>{const left=.65+j*4.18;
    s.addShape(p.ShapeType.line,{x:left,y:3,w:3.6,h:0,line:{color:'146C65',width:2}});
    txt(s,b.title,{x:left,y:3.3,w:3.6,h:.6,fontSize:26,bold:true});
    txt(s,b.body,{x:left,y:4.2,w:3.6,h:1.9,fontSize:20});});
  }else{
   const b=x.blocks[0];s.addTable([b.headers,...b.rows].map(r=>r.map(String)),{x:.65,y:2.65,w:12,colW:[5,1.8,2.6,2.6],rowH:.38,fontFace:font,fontSize:17,margin:.08,border:{type:'solid',color:'D0D8D8',pt:1},color:'172B35',fill:'FFFFFF'});
  }
  txt(s,`${x.id} · ${x.layout_id} · 合成示例 / 待视觉验收`,{x:.65,y:7.05,w:11,h:.22,fontSize:10,color:'677C82'});
  txt(s,String(i+1),{x:12.1,y:7.05,w:.5,h:.22,fontSize:10});
  s.addNotes(x.speaker_notes+'\n来源：'+JSON.stringify(x.sources));
 });
 fs.mkdirSync(path.dirname(path.resolve(output)),{recursive:true});await p.writeFile({fileName:output});console.log(output);
}
main().catch(e=>{console.error(e.message);process.exit(1)});
