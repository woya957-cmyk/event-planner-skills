#!/usr/bin/env python3
"""Calculate conservative whole-cycle capacity; operational estimate only."""
import argparse, json, math
from pathlib import Path
def calculate(d):
    for k in ('target','stations','batch_size','service_sec','window_sec'):
        if type(d[k]) is not int or d[k] <= 0: raise ValueError(k+' must be a positive integer')
    if type(d['reset_sec']) is not int or d['reset_sec'] < 0: raise ValueError('invalid reset_sec')
    if not isinstance(d['efficiency'],(int,float)) or not 0 < d['efficiency'] <= 1: raise ValueError('invalid efficiency')
    cycles=d['window_sec']//(d['service_sec']+d['reset_sec'])
    raw=d['stations']*d['batch_size']*cycles
    effective=math.floor(raw*d['efficiency'])
    per_station=d['batch_size']*cycles*d['efficiency']
    return {'cycles_per_station':cycles,'theoretical_person_visits':raw,'effective_person_visits':effective,
      'target_person_visits':d['target'],'shortfall':max(0,d['target']-effective),
      'stations_needed_arithmetic':math.ceil(d['target']/per_station) if per_station else None,
      'note':'运营估算，不是场地许可或安全容量；需另测高峰到达、空间与服务时间。'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('input');a=ap.parse_args()
    print(json.dumps(calculate(json.loads(Path(a.input).read_text(encoding='utf8'))),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
