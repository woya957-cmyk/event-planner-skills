#!/usr/bin/env python3
"""Create discovery links while keeping the repository's relative resources intact."""
import argparse,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--dest',required=True,help='explicit host skill discovery directory');ap.add_argument('--with-packs',action='store_true');ap.add_argument('--apply',action='store_true');a=ap.parse_args()
    dest=Path(a.dest).expanduser().resolve(); sources=sorted((ROOT/'skills').iterdir())
    if a.with_packs:sources+=sorted(p for p in (ROOT/'skill-packs').iterdir() if p.is_dir())
    pairs=[(p,dest/p.name) for p in sources if (p/'SKILL.md').is_file()]
    for src,target in pairs:
        if target.exists() or target.is_symlink():
            if target.is_symlink() and target.resolve()==src:continue
            raise SystemExit('Conflict, no changes made: '+str(target))
    for src,target in pairs:print(str(target)+' -> '+str(src))
    if not a.apply:print('Dry run. Add --apply to create these links.');return
    dest.mkdir(parents=True,exist_ok=True);created=[]
    try:
        for src,target in pairs:
            if target.is_symlink() and target.resolve()==src:continue
            target.symlink_to(src,target_is_directory=True);created.append(target)
    except OSError:
        for target in created:target.unlink()
        raise
    print('Installed. Keep the source folder in this location; no existing skills overwritten.')
if __name__=='__main__':main()
