#!/usr/bin/env python3
"""Export a reviewable text brief, not an API request or upload."""
import argparse,json
from pathlib import Path
def convert(data):
    parts=['# Presenton内容简报','16:9；保留原生文字与表格；按既定message排版。不得新增未提供的事实。']
    for s in data['slides']:
        parts.extend(['',f"## {s['id']} · {s['headline']}",f"版式规格ID：{s['layout_id']}",f"唯一判断：{s['message']}"])
        for b in s['blocks']:
            if b['kind']=='text':parts.append(b['title']+'：'+b['body'])
            elif b['kind']=='table':
                parts.append(json.dumps({'headers':b['headers'],'rows':b['rows']},ensure_ascii=False))
            else:parts.append('图像任务（尚未上传）：'+b['alt']+'；本地路径：'+b['path'])
        parts.append('讲稿：'+s['speaker_notes']);parts.append('来源：'+json.dumps(s['sources'],ensure_ascii=False))
    return '\n\n'.join(parts)+'\n'
def main():
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');a=ap.parse_args();out=Path(a.output)
    if out.exists():raise SystemExit('output exists; choose a new filename')
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(convert(json.loads(Path(a.input).read_text(encoding='utf8'))),encoding='utf8')
if __name__=='__main__':main()
