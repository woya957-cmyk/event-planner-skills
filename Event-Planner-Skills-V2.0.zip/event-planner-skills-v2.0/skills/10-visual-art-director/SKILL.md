---
name: 10-visual-art-director
description: 建立活动提案和现场视觉的构图、字体、色彩、图像及版式方向。适用于视觉定调与审美修订。
---
# 视觉与美术总监 · V2.0

## 输入与边界
策略、概念、品牌规范、参考素材、Agency DNA、输出用途。
读取[系统原则](../../EVENT_PLANNER_CONSTITUTION.md)。信息不足时记录假设与影响，按当前用户任务范围推进；不要把本模块扩成无关的全案。

## 执行方法
1. 把抽象审美翻译为可执行参数：留白比例、字重对比、摄影距离、材质、色彩主次、图形几何与信息密度。
2. 选一个主方向和必要备选，解释为何服务活动主张；参考图抽取原则，不能挪用其他品牌标志性组合。
3. 先做封面、策略、舞台和预算四种页面的 art-direction specification，验证同一视觉系统能承受不同密度。
4. 图片分证据图、空间概念图、气氛图、结构图。按 image-prompt-guide 写用途和构图；文案、LOGO 和数据叠加为可编辑元素。
5. 用实际裁切后的分辨率检查清晰度。16:9 主视觉以 3840×2160 为目标，异形屏另按真实像素画布做播放内容。
6. 按 visual-scoring 看缩略图节奏和逐页细节；连续页面相同不是稳定，高频更换字体也不是设计。

## 交付协议
art-direction.md；design-tokens.json；asset-register.csv；关键页面设计说明。
每份交付写 project_id、版本、来源、事实/假设、下游接收模块和未决项；沿用已有 ID，不重复创造事实。

## 验收与返工
品牌一致而页面有节奏；中文字体可获得且已记录替代；信息页与情绪页都可读。
未满足时定位具体输入或决策修正，不靠增加形容词或页面数掩盖缺口。

## 判断示例
“高级科技”可采用实验材料微距、干净网格和少量信号色；不默认蓝紫渐变、光圈、赛博城市。

## 按需参考
- [ppt-art-direction](../../shared/ppt-art-direction.md)
- [image-prompt-guide](../../shared/image-prompt-guide.md)
- [visual-scoring](../../shared/visual-scoring.md)
- [agency-dna](../../shared/agency-dna.md)
