---
name: 13-proposal-qa
description: 审查策略、创意、执行和PPT一致性，并以甲方视角提出可闭环修正。适用于交付前审查与方案红队。
---
# 提案质检 · V2.0

## 输入与边界
全部交付物、Brief、事实源、渲染图、评分记录和未决事项。
读取[系统原则](../../EVENT_PLANNER_CONSTITUTION.md)。信息不足时记录假设与影响，按当前用户任务范围推进；不要把本模块扩成无关的全案。

## 执行方法
1. 按需求矩阵逐条查覆盖；核对日期、人数、预算口径、活动名称和版本，不只查错字。
2. 策略轮检查因果和证据；创意轮检查品牌替换与跨媒介延展；执行轮重算容量、时长和预算；视觉轮检查渲染页。
3. 使用 proposal-red-team 从市场总监、采购、导演、现场观众视角提出最强反对；不能自问自答后自动打满分。
4. 问题分 blocker / major / minor，写证据文件或页码、影响、修复动作、负责模块及复核结果。
5. 修复后仅重查受影响依赖；重大预算或流程变化要回到相应质量门。保留没有条件验证的项，不把 pending 改成 pass。
6. 交付审计说明：已验证、未验证、假设、建议下一步。分数是内部评价，不保证中标、工程合规或现场效果。

## 交付协议
qa-report.md；red-team.md；问题闭环表；最终交付索引。
每份交付写 project_id、版本、来源、事实/假设、下游接收模块和未决项；沿用已有 ID，不重复创造事实。

## 验收与返工
无未解决 blocker；重要未决项在交付摘要可见；容量与预算由计算支持；视觉结论有渲染证据。
未满足时定位具体输入或决策修正，不靠增加形容词或页面数掩盖缺口。

## 判断示例
1200人分6台每人3分钟互动却标注45分钟全员完成，应判执行 blocker，而不是“建议优化体验”。

## 按需参考
- [proposal-red-team](../../shared/proposal-red-team.md)
- [creative-scoring](../../shared/creative-scoring.md)
- [visual-scoring](../../shared/visual-scoring.md)
- [interaction-capacity](../../shared/interaction-capacity.md)
