---
name: 12-ppt-builder
description: 按已定故事线和视觉规范构建16:9可编辑PPTX，验证素材、布局及导出。适用于方案文件生产。
---
# PPT制作 · V2.0

## 输入与边界
通过校验的 slides.json、设计参数、图片与字体、讲稿。
读取[系统原则](../../EVENT_PLANNER_CONSTITUTION.md)。信息不足时记录假设与影响，按当前用户任务范围推进；不要把本模块扩成无关的全案。

## 执行方法
1. 先验证 slides.json 与 layout_id 引用，再检查素材来源、实际像素和缺图状态；资料缺失不能用假效果图掩盖。
2. 阅读 integrations/pptxgenjs.md 或 integrations/presenton.md，按当前环境能力选择一条生成路径。不要假定 Presenton 导出可无损转换成 PptxGenJS 源代码。
3. 用原生文本、形状、表格和图表表达信息，效果图作为独立图片。SVG 可能只作为图片嵌入，不能自动宣称内部路径可编辑。
4. 默认16:9；字体先查可用性，缺字时明确替换并重排。预算和时间线由数据生成，不能手工复制多个版本。
5. 生成后渲染全部页面，检查缩略图节奏、逐页溢出、遮挡、字形、表格和图片；在可用 PowerPoint/WPS 中抽查编辑性。
6. 无渲染器时交付可编辑草稿并标注未完成视觉验收；不得以文件存在作为审美通过。修订只处理实际失败项。

## 交付协议
proposal.pptx；preview.pdf或逐页PNG（工具可用时）；editable-audit.md；qa-report.md；素材与源数据。
每份交付写 project_id、版本、来源、事实/假设、下游接收模块和未决项；沿用已有 ID，不重复创造事实。

## 验收与返工
无整页图片伪装；关键文字/表格能编辑；全部页面完成渲染检查或显式列出未验证项。
未满足时定位具体输入或决策修正，不靠增加形容词或页面数掩盖缺口。

## 判断示例
工程提供最小 PptxGenJS 适配器用于打通数据链；96个版式是设计规范，不宣称96种已实现自动渲染模板。

## 按需参考
- [slide-json-schema](../../shared/slide-json-schema.md)
- [ppt-art-direction](../../shared/ppt-art-direction.md)
- [visual-scoring](../../shared/visual-scoring.md)
