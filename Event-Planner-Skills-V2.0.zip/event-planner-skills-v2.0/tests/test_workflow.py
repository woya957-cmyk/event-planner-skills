import copy,importlib.util,json,sys,tempfile,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from capacity import calculate
from validate_project import validate
from extract_pptx_text import extract
from export_presenton_outline import convert
from jsonschema import Draft202012Validator
class WorkflowTests(unittest.TestCase):
 def test_known_bottleneck(self):
  d={'target':3000,'stations':6,'batch_size':1,'service_sec':180,'reset_sec':0,'window_sec':7200,'efficiency':.8}
  r=calculate(d);self.assertEqual(r['effective_person_visits'],192);self.assertEqual(r['shortfall'],2808);self.assertEqual(r['stations_needed_arithmetic'],94)
 def test_no_complete_cycle(self):
  r=calculate({'target':1,'stations':2,'batch_size':1,'service_sec':60,'reset_sec':0,'window_sec':30,'efficiency':1});self.assertEqual(r['effective_person_visits'],0);self.assertIsNone(r['stations_needed_arithmetic'])
 def test_examples_and_intentional_warning(self):
  for p in (ROOT/'examples').iterdir():
   r=validate(p);self.assertEqual(r['errors'],[],r)
   if p.name=='tech-festival-demo':self.assertEqual(r['capacity']['shortfall'],244)
 def test_schema_rejects_flattened_slide(self):
  schema=json.loads((ROOT/'schemas/slide.schema.json').read_text());d=json.loads((ROOT/'examples/annual-party-demo/slides.json').read_text());del d['slides'][0]['message']
  self.assertTrue(list(Draft202012Validator(schema).iter_errors(d)))
 def test_business_check_rejects_budget_mismatch(self):
  import shutil
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'case';shutil.copytree(ROOT/'examples/annual-party-demo',p)
   budget=p/'budget.csv';budget.write_text(budget.read_text().replace('70000,70000','70000,70001'))
   self.assertTrue(any('formula mismatch' in e for e in validate(p)['errors']))
 def test_profile_schemas(self):
  schema=json.loads((ROOT/'schemas/agency-profile.schema.json').read_text());v=Draft202012Validator(schema)
  for p in (ROOT/'agency-dna').glob('*.json'):self.assertEqual(list(v.iter_errors(json.loads(p.read_text()))),[])
 def test_extraction_follows_presentation_order(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'a.pptx'
   with zipfile.ZipFile(p,'w') as z:
    z.writestr('ppt/presentation.xml','<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:sldIdLst><p:sldId id="256" r:id="r2"/><p:sldId id="257" r:id="r1"/></p:sldIdLst></p:presentation>')
    z.writestr('ppt/_rels/presentation.xml.rels','<Relationships><Relationship Id="r1" Target="slides/slide1.xml"/><Relationship Id="r2" Target="slides/slide2.xml"/></Relationships>')
    for n in (1,2):z.writestr(f'ppt/slides/slide{n}.xml',f'<root xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:t>Page{n}</a:t></root>')
   self.assertEqual([s['text'][0] for s in extract(p)['slides']],['Page2','Page1'])
 def test_presenton_outline_preserves_core_message(self):
  d=json.loads((ROOT/'examples/brand-launch-demo/slides.json').read_text());s=convert(d)
  for slide in d['slides']:self.assertIn(slide['message'],s)
if __name__=='__main__':unittest.main()
