# Slide JSON数据契约

正式机器校验以[schemas/slide.schema.json](../schemas/slide.schema.json)为准，JSON Schema Draft 2020-12。文档说明不替代schema。

## 页面的必要内容
根对象：schema_version、project_id、aspect_ratio、slides。
每页：id、layout_id、headline、message、blocks、speaker_notes、sources、status。一个message代表一个判断；layout_id对应96版式索引。block用kind区分text、image、table；表格各行列数必须一致。图片记录asset_id、path、alt、nature与actual_pixels，path为相对项目目录的本地路径，禁止路径越界。

## 事实与视觉分离
页面不维护第二份预算事实源；生成前同步project和预算数据。来源对象包含id、locator、note，可指事实文件、用户Brief或明确的演示假设。status=draft/review/approved只描述工作状态，不能代替事实标签。

## 编辑性
text→原生文本，table→原生表格，image→可替换图片。舞台概念图片标nature=concept；照片标photo；资料图标reference。4K是图像生产目标，actual_pixels记录真实尺寸；不允许填目标值充当实际值。

## 校验顺序
1. JSON语法与schema；2. 页ID唯一、layout存在、表格列数；3. 文件和素材可用性；4. 事实一致与数字算式；5. 导出后渲染与实际编辑抽查。scripts/validate_project.py完成前两类及部分业务检查，不完成视觉评分。

工程的最小PptxGenJS适配器只实现CRE01、STR07、BUD01三个版式ID用于数据链示例；其他ID需要依据版式卡新增布局函数，遇到不支持ID会报错而非静默套版。
