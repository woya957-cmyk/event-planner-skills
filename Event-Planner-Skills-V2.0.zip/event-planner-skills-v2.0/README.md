# Event Planner Skills V2.0 · 活动公司实战版

一套面向活动公司高级策划、创意、导演、舞美、制片与提案团队的可用Skill工程。保留V1.0的00–13共14个核心角色，增加12种活动类型包、96个PPT版式规格、36种Show & Stage创意方法、Agency DNA和可校验的数据协议。

**默认16:9、视觉资产目标3840×2160、核心内容原生可编辑PPTX。** 不把口号当策略，不把效果图当施工图，不把整页图片当可编辑提案。先让活动机制成立，再让PPT有说服力。

## 下载后先做什么
1. 将完整工程放在稳定位置，保留目录关系；先读[系统原则](EVENT_PLANNER_CONSTITUTION.md)。
2. 直接让支持文件读取的代理读取 `skills/00-event-director/SKILL.md` 和当前类型包即可开始，无需先安装PPT软件。
3. 用真实Brief启动；如有优秀历史方案，按[Agency DNA](shared/agency-dna.md)提炼风格。未提供材料时使用untrained profile，不能声称已学会你的风格。
4. 从[三个示例](examples/annual-party-demo/README.md)理解交付物，替换真实资料后再推进正式项目。

## 安装与发现
Skill采用标准SKILL.md的name/description与按需引用。依据[官方技能文档](https://learn.chatgpt.com/docs/build-skills)，当前Codex本地技能可通过项目`.agents/skills`或用户级目录发现，并支持符号链接。不同宿主界面以其实际文档为准；本工程不自动修改用户环境。

建议在目标项目目录内指定安装位置。以下命令在**本工程根目录**执行：
```sh
python3 scripts/install_local.py --dest /你的项目/.agents/skills --with-packs
python3 scripts/install_local.py --dest /你的项目/.agents/skills --with-packs --apply
```
第一条预览，第二条创建14核心+12类型包的链接；存在冲突即停止且不覆盖原Skill。没有符号链接权限时可以直接按文件路径调用。保持本工程在原位置；不要只拷贝SKILL.md，否则shared、schemas和libraries相对引用会断。链接以源文件真实位置解析资源；代理读取时先定位本工程根目录。需要卸载只删除本安装生成的链接，保留源工程和其他技能。

## 调用方式
在支持技能选择的客户端选中00-event-director，或直接要求读取它。Codex CLI/IDE可用`$00-event-director`；其他界面的技能选择入口可能不同。`/event`仅可作为自行配置的别名，本工程没有注册这个命令。

```text
请读取 skills/00-event-director/SKILL.md，结合 annual-party 类型包。
为一个600人年会做完整竞标方案，预算上限36万元（含税，餐饮场租计入）。
目标是让跨部门贡献被看见。先区分事实与假设，完成策略、可延展创意、
关键节目分镜、空间、互动容量、执行和预算，再写逐页故事线。
默认16:9；核心文字和表格可编辑；视觉资产以4K为目标。
```

```text
读取 shared/agency-dna.md，用我提供的优秀PPT及评价提炼agency_profile。
记录证据页、公司/客户适用范围、反例和置信度；只提炼可复用规则，不照抄方案。
```

```text
只优化当前方案的开场与颁奖。使用06-show-director和相关方法卡，
保留已批准策略，给出分镜、时长、Cue、换场及降级方案。
```

## 目录
```text
event-planner-skills-v2.0/
├── README.md / EVENT_PLANNER_CONSTITUTION.md / manifest.json
├── skills/               00–13核心Skills
├── skill-packs/          12个活动类型包与索引
├── shared/               方法、评分、红队、容量、舞美、图像、PPT、DNA、数据协议
├── libraries/
│   ├── ppt-layouts/      96张版式规格卡 + JSON索引
│   └── show-stage/       36张导演与空间方法卡 + JSON索引
├── agency-dna/           待学习profile、合成demo和证据说明
├── schemas/              6份JSON Schema Draft 2020-12
├── templates/            12类Brief + 创意路线/交接/DNA证据工作纸
├── examples/             年会、科技文化节、发布会的有内容skeleton
├── integrations/         PptxGenJS与Presenton组合说明
├── scripts/              安装、计算、校验、PPTX文本提取、简报和最小PPT导出
├── tests/                业务与脚本回归测试
└── QA_REPORT.md          本次工程检查结果与能力边界
```

## 核心职责
- [00-event-director｜活动策划总监](skills/00-event-director/SKILL.md)
- [01-brief-analyzer｜需求分析](skills/01-brief-analyzer/SKILL.md)
- [02-research-insight｜研究与洞察](skills/02-research-insight/SKILL.md)
- [03-strategy-architect｜策略架构](skills/03-strategy-architect/SKILL.md)
- [04-creative-director｜创意总监](skills/04-creative-director/SKILL.md)
- [05-experience-designer｜体验设计](skills/05-experience-designer/SKILL.md)
- [06-show-director｜演出导演](skills/06-show-director/SKILL.md)
- [07-space-stage-designer｜空间与舞美设计](skills/07-space-stage-designer/SKILL.md)
- [08-interaction-designer｜互动设计](skills/08-interaction-designer/SKILL.md)
- [09-event-producer｜执行制片](skills/09-event-producer/SKILL.md)
- [10-visual-art-director｜视觉与美术总监](skills/10-visual-art-director/SKILL.md)
- [11-ppt-storytelling｜提案叙事](skills/11-ppt-storytelling/SKILL.md)
- [12-ppt-builder｜PPT制作](skills/12-ppt-builder/SKILL.md)
- [13-proposal-qa｜提案质检](skills/13-proposal-qa/SKILL.md)

## 活动类型包
- [annual-party｜年会](skill-packs/annual-party/SKILL.md)：组织认可与员工关系
- [corporate-anniversary｜企业司庆](skill-packs/corporate-anniversary/SKILL.md)：历史证据与未来承诺
- [conference｜峰会/会议](skill-packs/conference/SKILL.md)：观点质量与有效连接
- [technology-festival｜科技文化节](skill-packs/technology-festival/SKILL.md)：把技术变成可参与的创造
- [product-launch｜产品发布会](skill-packs/product-launch/SKILL.md)：把产品主张变成可信证据
- [brand-activation｜品牌活动/快闪](skill-packs/brand-activation/SKILL.md)：把品牌态度化为公众动作
- [award-show｜颁奖礼](skill-packs/award-show/SKILL.md)：让荣誉有理由且让全场有共鸣
- [entertainment-show｜演出活动](skill-packs/entertainment-show/SKILL.md)：建立完整的情绪与观看体验
- [outdoor-event｜户外活动](skill-packs/outdoor-event/SKILL.md)：让环境成为体验且运营可切换
- [sports-event｜体育活动/运动团建](skill-packs/sports-event/SKILL.md)：公平参与与适配体能的合作
- [family-day｜家庭日](skill-packs/family-day/SKILL.md)：让家属理解工作并共同留下回忆
- [exhibition-roadshow｜展览/路演](skill-packs/exhibition-roadshow/SKILL.md)：空间叙事与可复制的巡回体验

## PPT与导演库
[96版式总索引](shared/ppt-layout-library.md)分12类，每类8个：策略、创意、体验、舞美空间、节目、互动、执行、预算、时间轴、视觉素材、组织叙事、提案决策。每卡有适用场景、信息结构、视觉层级、禁忌与制作验收。

[36种Show & Stage方法](libraries/show-stage/README.md)分9类，每类4种：开场、仪式、颁奖、员工、音乐、多媒体、技术、Ending、空间。内容是原创机制，不复刻商业案例；使用前需做品牌转译与制作复核。

## 推荐生产工作流
Brief→01分析→02洞察→03策略→04创意→05–09体验/导演/舞美/互动/执行互相校正→10美术→11叙事与slides.json→12生成→13质量与红队。00贯穿管理事实、版本与需求覆盖。

[PptxGenJS路径](integrations/pptxgenjs.md)：更适合按自有规则精确构建原生可编辑元素。工程附可运行最小适配器，实现3个基础版式；其他93种是可供制作的规格卡，需要继续实现对应布局函数。

[Presenton路径](integrations/presenton.md)：将已确认内容和美术规范交给当前可用实例生成、编辑和导出。工程附离线简报导出器，不包含自动部署/上传或固定API绑定。二者共享内容源，不能假定相互无损转换。

## 校验与示例
```sh
python3 -m venv .venv
# 激活虚拟环境后安装；Windows使用对应的激活脚本
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 scripts/validate_project.py examples/annual-party-demo
python3 scripts/capacity.py examples/tech-festival-demo/capacity.json
python3 -m unittest discover -s tests -v
```
科技节故意保留“300人单人深度体验只有56人次容量”的设计反例：普通校验报告警告，`--strict-capacity`会失败；qa-notes提供团队参与的调整方向。结构通过不等于执行通过。

三个示例都填有project、concept、capacity、budget、节目Cue、Rundown、storyboard、production和QA。每例slides.json只有3页演示数据，**不宣称是完整竞标PPT**。本次交付是可用Skill工程，未自动生成4K资产或全案PPT，也未实际学习用户历史文件。

## 维护
保持事实、推断与假设标签；规则修改记录版本与反例；新活动包补专属决策而不复制核心流程；新版式有明确新信息关系才入库。规则服务真实任务，用户明确需求与当前品牌约束优先。参见[QA报告](QA_REPORT.md)与[检查用例](tests/behavioral-scenarios.md)。

## 来源与原创范围
技能本地发现方式据官方文档；PPT工具能力据其官方资料，链接见integrations。活动方法、96版式描述、36创意卡、示例和脚本为本次工程编写；不附带商业案例、付费模板、字体或图片授权。没有把历史对话中未经核实的GitHub推荐作为依赖。
