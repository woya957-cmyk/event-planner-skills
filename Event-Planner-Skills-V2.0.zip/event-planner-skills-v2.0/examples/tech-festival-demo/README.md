# 把想法做出来 · technology-festival 示例 skeleton

**合成教学项目，不代表真实客户、报价、研究或已举办案例。** 文件有实际示例内容用于启动下一阶段，不是最终可投标方案，也未生成全案PPT。

## 已填内容
project.json包含事实口径与假设；concept.json提供机制与跨媒介延展；capacity.json可复算吞吐；budget.csv合计240,000元；show-program.json包含节目、转场与Cue；rundown.csv记录相对时间；slides.json含3页可导出的数据样例；storyboard.md规划全案；production-plan.md与qa-notes.md记录待核条件。

## 使用
先用真实Brief替换project.json，再按本活动类型Pack推进。运行 `python scripts/validate_project.py examples/tech-festival-demo`（工程根目录）；安装jsonschema依赖后可校验。运行 `python scripts/capacity.py examples/tech-festival-demo/capacity.json` 查看容量。
最小PPT适配器只导出3页数据样例，见[integrations/pptxgenjs.md](../../integrations/pptxgenjs.md)。完整视觉提案需按故事线扩展、制作素材并渲染验收。

## 下一步
补品牌独有材料、真实受众证据、场地条件、预算询价和节目排练，不能把本例名称、金额和参数直接作为客户最终承诺。
