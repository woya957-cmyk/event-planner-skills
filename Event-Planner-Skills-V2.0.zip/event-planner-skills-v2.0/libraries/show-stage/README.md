# Show & Stage Creative Library · 36种原创方法

按导演任务选方法，再用真实项目材料重写；不是节目采购目录或技术实施方案。每卡含戏剧机制、前提、降级与验收。

- [开场秀｜微动作汇流](opening/opening-01.md)：把个体贡献变成集体结果
- [开场秀｜未完成的问题](opening/opening-02.md)：给产品或会议建立悬念
- [开场秀｜观众先成为角色](opening/opening-03.md)：让全场从旁观进入参与
- [开场秀｜日常声音成乐](opening/opening-04.md)：从熟悉感进入舞台
- [仪式｜交接的责任](ceremony/ceremony-01.md)：让启动对应实际行动
- [仪式｜共同补上缺口](ceremony/ceremony-02.md)：让集体结果具有因果
- [仪式｜从幕后到台前](ceremony/ceremony-03.md)：把幕后贡献变成主角
- [仪式｜第一次真实使用](ceremony/ceremony-04.md)：发布或开业建立实证
- [颁奖｜贡献被看见](awards/awards-01.md)：让荣誉有证据
- [颁奖｜集体成果分层](awards/awards-02.md)：多人领奖保持节奏
- [颁奖｜把荣誉变成邀请](awards/awards-03.md)：连接未获奖观众
- [颁奖｜一奖一节奏](awards/awards-04.md)：避免颁奖疲劳
- [员工节目｜真实技能上舞台](employee/employee-01.md)：减少扮演负担
- [员工节目｜一句话群像](employee/employee-02.md)：让更多人参与又控时
- [员工节目｜代际互教](employee/employee-03.md)：把文化传承变成动作
- [员工节目｜可组合节目模块](employee/employee-04.md)：适配有限排练时间
- [音乐节目｜同一旋律变奏](music/music-01.md)：表达组织或产品变化
- [音乐节目｜人声与环境对话](music/music-02.md)：让品牌声音成为音乐
- [音乐节目｜观众可加入的副句](music/music-03.md)：形成共鸣而不强迫合唱
- [音乐节目｜音乐与静默落差](music/music-04.md)：制造被准备的高潮
- [多媒体秀｜屏幕作为回应者](multimedia/multimedia-01.md)：让真人拥有主导权
- [多媒体秀｜尺度迁移](multimedia/multimedia-02.md)：把细节变成空间
- [多媒体秀｜远方的现场连线](multimedia/multimedia-03.md)：把异地团队带到场内
- [多媒体秀｜现场数据成形](multimedia/multimedia-04.md)：让集体参与可见
- [技术秀｜能力对照任务](technical/technical-01.md)：证明技术作用
- [技术秀｜人机分工戏剧](technical/technical-02.md)：说明技术与人的关系
- [技术秀｜可视化信号旅程](technical/technical-03.md)：让复杂技术可理解
- [技术秀｜单点技术惊喜](technical/technical-04.md)：在可靠基础上增加新鲜感
- [Ending｜母题回来但已改变](ending/ending-01.md)：完成故事闭环
- [Ending｜成果交给观众](ending/ending-02.md)：让离场成为行动起点
- [Ending｜安静的致意](ending/ending-03.md)：为高能量演出降落
- [Ending｜分散式尾声](ending/ending-04.md)：缓解集中离场
- [舞台空间｜可被使用的建筑](space/space-01.md)：让舞美成为表演伙伴
- [舞台空间｜光形成边界](space/space-02.md)：减少实体搭建
- [舞台空间｜前景中景远景](space/space-03.md)：建立镜头和现场纵深
- [舞台空间｜模块可变但逻辑不变](space/space-04.md)：支持巡回和预算变化
