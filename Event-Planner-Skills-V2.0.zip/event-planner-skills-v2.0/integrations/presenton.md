# Presenton：内容与视觉生成路径

官方[Presenton项目](https://github.com/presenton/presenton)提供演示生成、模板和可编辑PPTX导出能力，支持自托管方式；资料核对于2026-09-10。本工程只提供内容简报适配，不附带服务部署或未经验证的API客户端。

## 推荐组合
00–09完成策划与可行性 → Agency DNA提供风格约束 → 10定义美术规范 → 11输出slides.json → 导出简报 → 在用户选定的Presenton实例使用模板/文档生成 → 核对PPTX → 13审查。

```sh
python3 scripts/export_presenton_outline.py examples/brand-launch-demo/slides.json work/presenton-brief.md
```
生成简报后，把其内容与art-direction、相关版式规格提供给当前Presenton工作流。不要假定本工程layout_id是Presenton内置模板ID。图片上传前确认当前授权与数据范围；本地私密材料优先在合适的本地/受控环境处理。

## 两种部署不要混淆
自托管/桌面项目：按当前官方仓库说明安装与配置模型、模板和导出能力，API以该实例文档为准。
已安装的Presenton插件：读取当时插件Skill及接口合同再调用；导出格式、上传与临时文件要求依插件实际版本。本工程不固化公有服务端点，不承诺免费、免密钥或固定链接有效期。

## 与PptxGenJS的关系
两者是可选渲染路径，共享已经确认的内容契约。Presenton不能被默认视为PptxGenJS源代码生成器；也不假定它导出的PPTX能无损回转JSON。若要用PptxGenJS精修，回到源数据重建所需页，保留已批准内容版本。

## 验收
导出后逐页比对唯一message、事实、预算和素材；检查中文字体、表格、日期、流程节点是否可编辑。HTML/CSS特效是否被正确转换须看实测。核心不可编辑时明确局限并重建相应页，不以平台能力宣传替代检查。
