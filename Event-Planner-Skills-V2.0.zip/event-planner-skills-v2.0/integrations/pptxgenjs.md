# PptxGenJS：原生可编辑生产路径

已核对官方[Quick Start](https://gitbrent.github.io/PptxGenJS/docs/quick-start/)（2026-09-10）：通过代码创建页与对象并写出PPTX。本工程适配器采用4.0.1，文字和表格以原生元素创建。官方资料支持的是工具能力，本工程的96个版式设计为独立编写。

## 启动
在工程根目录执行：
```sh
npm install
python3 -m pip install -r requirements.txt
python3 scripts/validate_project.py examples/annual-party-demo
node scripts/build_pptx.cjs examples/annual-party-demo/slides.json work/annual-party-demo.pptx
```
在隔离Python环境安装依赖更便于维护。字体默认Microsoft YaHei；实际不存在时通过环境变量EVENT_PPT_FONT指定已安装中文字体并重新检查排版。这里不附带字体授权或自动安装字体。

## 能力边界
最小适配器实现 CRE01（命题）、STR07（三支柱）、BUD01（预算）3种布局。其他layout_id会报错；图片放置也需新建对应实现。此脚本用于验证内容数据→可编辑PPTX的闭环，不是96版式全自动排版引擎。每页固定注明合成示例与待视觉验收，适合示例验证；生产版本需完成设计和QA后调整标签。

## 扩展方式
1. 从版式卡识别必要内容块与视觉层级。
2. 为该layout_id实现独立函数，写明输入范围；表格过长拆页而非缩小到不可读。
3. 图片独立置入并标性质；源数据留存。预算、日期、流程不栅格化。
4. 选择短文本、长中文、缺图和密集表格样本验证，再加入支持列表。
5. 生成后渲染全页，在PowerPoint或WPS实际打开，抽改标题/表格/日期；记录缺字、字体回退、对象覆盖和编辑性。

## 交付
PPTX、源JSON、适配器、素材台账与QA报告。若无渲染器，明确视觉验收未完成；不要把文件导出成功写成审美通过。4K素材目标在图像生成阶段检查，PPTX页面本身不按像素定义。
